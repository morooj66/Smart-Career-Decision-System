# Smart Career Decision System — Technical Explanation

> Developed as part of the AI Agents Program at SDAIA Academy.

---

## 1. What is a Multi-Agent System?

A multi-agent system is a design pattern where instead of asking one LLM to do
everything in a single prompt, we split the work into specialized agents.
Each agent has a **single responsibility**, a **specific method**, and
**clearly defined inputs and outputs**.

This makes the system:
- **More reliable** — each agent is focused and less likely to hallucinate.
- **More debuggable** — you can trace exactly which agent produced which output.
- **More maintainable** — you can improve one agent without touching others.

---

## 2. Why LangGraph?

LangGraph manages the flow between agents using a **StateGraph**.

Without LangGraph, you would write complex if/else chains and manually
pass data between functions. LangGraph replaces this with:

- **Nodes** — each agent is a node.
- **Edges** — define the order of execution.
- **State** — a shared `TypedDict` that all agents read from and write to.
- **MemorySaver** — stores the state per thread_id (supports multi-turn).

```python
builder = StateGraph(WorkflowState)
builder.add_node("planner",          planner_node)
builder.add_node("research",         research_node)
builder.add_node("profile_analyzer", profile_analyzer_node)
builder.add_node("scorer",           scorer_node)
builder.add_node("decision",         decision_node)

builder.set_entry_point("planner")
builder.add_edge("planner",          "research")
builder.add_edge("research",         "profile_analyzer")
builder.add_edge("profile_analyzer", "scorer")
builder.add_edge("scorer",           "decision")
builder.add_edge("decision",         END)

graph = builder.compile(checkpointer=MemorySaver())
```

---

## 3. The Shared State

```python
class WorkflowState(TypedDict):
    user_input:      Dict[str, Any]   # raw input from the user
    planner_output:  Optional[dict]   # filled by Planner Agent
    research_output: Optional[dict]   # filled by Research Agent
    profile_output:  Optional[dict]   # filled by Profile Analyzer
    scores:          Optional[list]   # filled by Scorer Agent
    decision_output: Optional[dict]   # filled by Decision Agent
    status_log:      List[str]        # trace log for the Gradio output
```

Every agent receives the **full state**, reads what it needs, adds its output,
and returns the updated state to LangGraph.

---

## 4. Agent Deep Dive

### Agent 1 — Planner Agent

**Goal:** Transform the user's raw text input into a clean, structured object.

**Method:** `llm.with_structured_output(PlannerOutput)`

This forces the LLM to return a response that matches the `PlannerOutput`
Pydantic schema. If the LLM returns something that doesn't match, Pydantic
raises a validation error automatically.

```python
class PlannerOutput(BaseModel):
    selected_paths:     List[str]
    current_skills:     List[str]   # normalized, deduplicated
    interests:          List[str]   # normalized, deduplicated
    goal:               str
    needs_web_research: bool        # controls Research Agent behavior
```

---

### Agent 2 — Research Agent

**Goal:** Gather structured information about each selected career path.

**Method:** `llm.bind_tools([...])` + manual ReAct loop (up to 12 iterations)

This is the most complex agent. It uses the **ReAct pattern**:
1. LLM decides which tool to call and with what arguments.
2. The system executes the tool.
3. The result is added to the message history as a `ToolMessage`.
4. The LLM sees the result and decides whether to call another tool or stop.
5. When no more tool calls are made, the LLM writes its final JSON output.

**Tools available:**
- `get_local_career_info(path_name)` — always called first for each path.
- `web_search(query)` — called only if `needs_web_research=true`.
- `fetch_url(url)` — called optionally for deeper content from a search result.

**Failure handling:** If a tool returns `ok=false`, the agent continues
with available data. The system never crashes on tool failure.

---

### Agent 3 — Profile Analyzer Agent

**Goal:** Understand the user's strengths, weaknesses, and personality fit.

**Method:** `llm.with_structured_output(ProfileOutput)`

```python
class ProfileOutput(BaseModel):
    strengths:       List[str]   # what the user already has
    weaknesses:      List[str]   # skill gaps vs. path requirements
    personality_fit: str         # one sentence on role suitability
```

The agent receives a compact payload: user skills, interests, goal,
and a 2-point summary per path from the research output.

---

### Agent 4 — Scorer Agent

**Goal:** Compute objective, reproducible match scores for each path.

**Method:** Calls `score_path` tool directly for each path — no LLM involved.

This is intentionally **deterministic** — the same input always produces
the same score. This prevents the LLM from changing its mind arbitrarily.

**Scoring formula:**
```
score = skill_alignment (0–60) + interest_alignment (0–40)
      = max 100 points

skill_alignment    = (fuzzy_matched_skills / min(7, core_skill_count)) × 60
interest_alignment = (fuzzy_matched_interests / min(4, signal_count)) × 40
```

**Fuzzy matching** means "python" matches "python basics" and vice versa —
avoiding zero scores due to exact-string mismatch.

---

### Agent 5 — Decision Agent

**Goal:** Synthesize all previous outputs into a final recommendation.

**Method:** `llm.invoke(messages)` → `_safe_parse_json(response, fallback)`

The agent receives the full state (planner + research + profile + scores)
and is instructed to return a specific JSON schema:

```json
{
  "best_path": "AI Engineer",
  "reason": "2-3 sentences...",
  "skill_gaps": ["gap1", "gap2", "gap3"],
  "next_steps": ["step1", "step2", "step3", "step4"]
}
```

**Anchor rule:** The `best_path` is always overwritten by the path with
the highest Scorer Agent score. This prevents the LLM from recommending
a different path despite the numbers.

**Safe JSON parsing:** The `_safe_parse_json` helper strips markdown fences,
tries `json.loads`, then falls back to regex extraction, then returns
a pre-defined fallback. The agent **never crashes**.

---

## 5. Tools Deep Dive

### `get_local_career_info`

Returns one entry from `LOCAL_CAREER_KB` — a hand-curated dictionary
containing: summary, core_skills, typical_projects, tools, signals_of_fit,
learning_path, avg_salary_usd, demand_trend.

No network call. Always succeeds. This is the primary data source.

### `web_search`

Wraps `duckduckgo-search` (DDGS). Returns up to 4 results with title,
URL, and snippet. No API key required. Catches all exceptions and returns
`ok=false` with an error message instead of crashing.

### `fetch_url`

Downloads a URL, parses it with BeautifulSoup, strips noise (scripts,
styles, nav, footer), and returns the first 3000 characters of clean text.
Handles timeouts, HTTP errors, and connection errors gracefully.

### `score_path`

A pure Python function decorated with `@tool`. Takes user_skills,
user_interests, path_name, and path_data. Returns a score dict with
breakdown and explanation. Fully deterministic — no LLM call.

---

## 6. LangChain Concepts Used

| Concept | Where Used |
|---------|-----------|
| `with_structured_output(Schema)` | Planner Agent, Profile Analyzer |
| `bind_tools([...])` | Research Agent |
| `@tool` decorator | All 4 tools |
| `SystemMessage`, `HumanMessage` | All agents |
| `ToolMessage` | Research Agent tool loop |
| `AIMessage` | Research Agent output |

---

## 7. Gradio UI

The Gradio interface is built with `gr.Blocks` and uses:
- `gr.CheckboxGroup` — path selection
- `gr.Textbox` — skills, interests, goal inputs
- `gr.Button` — trigger analysis
- `gr.Textbox` (read-only) — formatted text output

The user sees a single form. All 5 agents and the LangGraph pipeline
run invisibly in the background. The only output is a clean text report.

---

## 8. Security

- API key is loaded from `.env` via `python-dotenv`.
- `.env` is in `.gitignore` — never committed to Git.
- `.env.example` is committed — shows the key name without the value.
- No key is hardcoded anywhere in `app.py`.

---

## 9. Error Handling Summary

| Failure Point | Handling |
|--------------|---------|
| Missing API key | Raises `EnvironmentError` with clear message at startup |
| Empty user input | Validation in `gradio_submit` — returns friendly error |
| Tool call failure | `_execute_tool_calls` catches all exceptions per tool |
| Web search failure | Returns `ok=false` dict — Research Agent continues |
| URL fetch failure | Returns `ok=false` dict — Research Agent continues |
| LLM returns invalid JSON | `_safe_parse_json` tries 3 strategies then uses fallback |
| Unknown tool called | Returns `{"error": "Unknown tool: X", "ok": false}` |
| Any uncaught exception | `gradio_submit` wraps everything in try/except |
